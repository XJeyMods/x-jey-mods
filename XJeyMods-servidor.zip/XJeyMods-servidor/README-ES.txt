XJEYMODS — SERVIDOR DE VALIDACIÓN DE KEYS
==========================================

Este paquete es una base inicial del servidor. Todavía NO está publicado y NO está conectado a tu APK.

Qué hace:
- POST /api/validate-key: comprueba una Key en MongoDB Atlas.
- Responde {"valid":false,"message":"Key invalida"} si no existe/no está activa.
- Responde {"valid":true,"message":"Key correcta"} si es válida.
- Opcionalmente asigna una Key al primer dispositivo/IP si el documento tiene bindOnFirstUse=true.
- POST /api/admin/keys: permite crear Keys con un token administrativo guardado SOLO en el servidor.

ANTES DE USAR:
1. Crea una base de datos gratuita en MongoDB Atlas.
2. En Atlas crea un usuario de base de datos y permite acceso de red solo según la configuración necesaria.
3. Publica esta carpeta como un Web Service de Node en Render.
4. En Environment Variables de Render configura:
   MONGODB_URI = tu cadena privada de conexión de Atlas
   DB_NAME = xjeymods
   KEYS_COLLECTION = keys
   ADMIN_TOKEN = una contraseña larga aleatoria
5. Nunca pongas MONGODB_URI ni ADMIN_TOKEN dentro de la APK ni los compartas en el chat.
6. Comprueba https://TU-SERVIDOR/health. Debe responder {"ok":true,...}.

Crear una Key:
Envía una petición POST a https://TU-SERVIDOR/api/admin/keys
Header: x-admin-token: TU_ADMIN_TOKEN
JSON:
{"key":"TU-KEY-001","active":true,"bindOnFirstUse":true}

Validar una Key:
POST https://TU-SERVIDOR/api/validate-key
JSON:
{"key":"TU-KEY-001","deviceId":"identificador-generado-por-la-app"}

IMPORTANTE:
- Este servidor todavía no modifica la APK ni sabe qué identificador de dispositivo usa.
- El servidor debe publicarse y probarse antes de editar smali con MT Manager.
- La IP puede cambiar y no identifica de forma fiable a un teléfono. Si quieres una asignación más estable, usa un identificador aleatorio generado por la app y considera la IP solo como señal adicional.
- Para producción hay que ajustar los campos de asignación al comportamiento exacto que deseas.
