const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const { MongoClient } = require("mongodb");

const app = express();
app.use(express.json({ limit: "10kb" }));
app.use(cors()); // Restringe los origenes si luego agregas clientes web.
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 30 }));

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = process.env.DB_NAME || "xjeymods";
const COLLECTION = process.env.KEYS_COLLECTION || "keys";
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

let collection;

function cleanString(value, max = 200) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "XJeyMods key server" }));

app.post("/api/validate-key", async (req, res) => {
  try {
    const key = cleanString(req.body?.key, 256);
    const deviceId = cleanString(req.body?.deviceId, 256);
    // La IP se obtiene del servidor; no se acepta una IP enviada por la app.
    const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "")
      .toString().split(",")[0].trim().slice(0, 100);

    if (!key) return res.status(400).json({ valid: false, message: "Key invalida" });

    const record = await collection.findOne({ key, active: { $ne: false } });
    if (!record) return res.status(200).json({ valid: false, message: "Key invalida" });

    // Opcional: asignar la Key al primer dispositivo/IP que la use.
    // Para habilitarlo, establece bindOnFirstUse=true en el documento de la Key.
    if (record.bindOnFirstUse === true) {
      const owner = record.owner || {};
      if (!owner.deviceId && !owner.ip) {
        await collection.updateOne(
          { _id: record._id, $or: [{ "owner.deviceId": { $exists: false } }, { "owner.ip": { $exists: false } }] },
          { $set: { owner: { deviceId, ip }, firstUsedAt: new Date() } }
        );
      } else if ((owner.deviceId && owner.deviceId !== deviceId) || (owner.ip && owner.ip !== ip)) {
        return res.status(200).json({ valid: false, message: "Key invalida" });
      }
    }

    return res.json({ valid: true, message: "Key correcta" });
  } catch (err) {
    console.error("Error validando Key:", err.message);
    return res.status(500).json({ valid: false, message: "Error del servidor" });
  }
});

// Endpoint administrativo inicial protegido por token. Nunca pongas este token en la APK.
app.post("/api/admin/keys", async (req, res) => {
  const token = cleanString(req.headers["x-admin-token"], 512);
  if (!ADMIN_TOKEN || token !== ADMIN_TOKEN) return res.status(401).json({ error: "No autorizado" });

  const key = cleanString(req.body?.key, 256);
  if (!key) return res.status(400).json({ error: "Falta key" });

  try {
    const doc = {
      key,
      active: req.body?.active !== false,
      bindOnFirstUse: req.body?.bindOnFirstUse === true,
      createdAt: new Date()
    };
    await collection.updateOne({ key }, { $setOnInsert: doc }, { upsert: true });
    return res.json({ ok: true });
  } catch (err) {
    console.error("Error creando Key:", err.message);
    return res.status(500).json({ error: "Error del servidor" });
  }
});

async function start() {
  if (!MONGODB_URI) {
    console.error("Falta configurar MONGODB_URI como variable de entorno.");
    process.exit(1);
  }
  const client = new MongoClient(MONGODB_URI);
  await client.connect();
  const db = client.db(DB_NAME);
  collection = db.collection(COLLECTION);
  await collection.createIndex({ key: 1 }, { unique: true });
  app.listen(PORT, "0.0.0.0", () => console.log(`Servidor iniciado en puerto ${PORT}`));
}
start().catch(err => {
  console.error("No se pudo iniciar el servidor:", err.message);
  process.exit(1);
});
