package com.holovip;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.app.Activity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.functions.FirebaseFunctions;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseFunctions functions;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApplicationId("1:1084565520750:android:3788805037e7b8f273c17f")
                .setApiKey("AIzaSyDR8rJCf47mMeV_jK-Jj1zVicIsg-ugxXc")
                .setProjectId("xjeymods")
                .setDatabaseUrl("https://xjeymods-default-rtdb.firebaseio.com")
                .build();
        if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this, options);
        functions = FirebaseFunctions.getInstance("us-central1");

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void validateKey(String key) {
            String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            Map<String,Object> data = new HashMap<>();
            data.put("key", key);
            data.put("deviceId", deviceId == null ? "" : deviceId);
            functions.getHttpsCallable("validateKey").call(data)
                .addOnSuccessListener(result -> {
                    Map<?,?> r = (Map<?,?>) result.getData();
                    boolean ok = Boolean.TRUE.equals(r.get("ok"));
                    String message = String.valueOf(r.get("message"));
                    runJs(ok, message);
                })
                .addOnFailureListener(e -> runJs(false, "ERROR DE CONEXIÓN"));
        }
    }

    private void runJs(boolean ok, String message) {
        String safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        runOnUiThread(() -> webView.evaluateJavascript("onValidationResult(" + ok + ", '" + safe + "')", null));
    }
}
