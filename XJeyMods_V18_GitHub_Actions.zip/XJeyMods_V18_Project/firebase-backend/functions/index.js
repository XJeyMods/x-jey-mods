const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');
const crypto = require('crypto');

initializeApp({ databaseURL: 'https://xjeymods-default-rtdb.firebaseio.com' });
const db = getDatabase();
const TWELVE_HOURS = 12 * 60 * 60 * 1000;

function normalizeKey(value) {
  if (typeof value !== 'string') return '';
  const raw = value.trim();
  const m = raw.match(/^xjey-mods-([A-Za-z0-9]{4})$/i);
  return m ? `xjey-mods-${m[1].toUpperCase()}` : raw;
}

function hashDeviceId(value) {
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

exports.validateKey = onCall({ region: 'us-central1' }, async (request) => {
  const key = normalizeKey(request.data?.key);
  const deviceId = typeof request.data?.deviceId === 'string' ? request.data.deviceId.trim() : '';
  if (!key || !deviceId) throw new HttpsError('invalid-argument', 'Datos incompletos');

  const deviceHash = hashDeviceId(deviceId);
  const ref = db.ref(`keys/${key}`);
  const initial = await ref.get();
  if (!initial.exists()) return { ok: false, message: 'KEY INVALIDA', code: 'INVALID' };

  const now = Date.now();
  const tx = await ref.transaction(current => {
    if (!current) return;
    if (!current.deviceId || !current.activatedAt) {
      return {
        ...current,
        deviceId: deviceHash,
        activatedAt: now,
        expiresAt: now + TWELVE_HOURS,
        active: true
      };
    }
    if (current.deviceId !== deviceHash) return;
    if (Number(current.expiresAt || (Number(current.activatedAt) + TWELVE_HOURS)) <= now) {
      return { ...current, active: false };
    }
    return { ...current, active: true };
  });

  const finalSnap = await ref.get();
  if (!finalSnap.exists()) return { ok: false, message: 'KEY INVALIDA', code: 'INVALID' };
  const final = finalSnap.val();
  const expiresAt = Number(final.expiresAt || (Number(final.activatedAt) + TWELVE_HOURS));

  if (final.deviceId !== deviceHash) {
    return { ok: false, message: 'KEY YA UTILIZADA EN OTRO DISPOSITIVO', code: 'USED' };
  }
  if (expiresAt <= Date.now() || final.active === false) {
    return { ok: false, message: 'KEY EXPIRADA', code: 'EXPIRED' };
  }
  return { ok: true, message: 'ACCESO CONCEDIDO', code: 'OK', expiresAt };
});
